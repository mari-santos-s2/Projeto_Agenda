package com.teste.crudspring.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.teste.crudspring.model.Pessoa;

public interface PessoaRepository extends JpaRepository<Pessoa, Integer>{

	
}
