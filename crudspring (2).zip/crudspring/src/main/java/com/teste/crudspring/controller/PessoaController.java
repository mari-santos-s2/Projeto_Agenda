package com.teste.crudspring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.server.ResponseStatusException;

import com.teste.crudspring.model.Pessoa;
import com.teste.crudspring.repository.PessoaRepository;

@RestController
@RequestMapping("/pessoas")
public class PessoaController {
	
	@Autowired  // injeção de dependencia
	private PessoaRepository repository;
	
	/*
	@PostMapping("/CreateUser")
    @ResponseStatus(code = HttpStatus.CREATED)
    public Pessoa cadastrar(@RequestBody Pessoa pessoa) {
        return repository.save(pessoa);
    }
	*/
	
	@PostMapping("/CreateUser")
	public ResponseEntity<Object> saveUser(@RequestBody Pessoa pessoa){
		return ResponseEntity.status(HttpStatus.CREATED).body(repository.save(pessoa));
	}
	
	@GetMapping
    public List<Pessoa> listar() {
        return repository.findAll();
    }

	/*
	@GetMapping("/{id}")
    public Pessoa buscarPorId(@PathVariable Integer id) {
        var pessoaOptional = repository.findById(id);
        if (pessoaOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return pessoaOptional.get();
    }
	*/
	@GetMapping("/{id}")
    public Pessoa buscarPorId(@PathVariable Integer id) {
        var pessoaOptional = repository.findById(id);
        if (pessoaOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
        return pessoaOptional.get();
    }
	
	
	
	@DeleteMapping("/{id}")
    @ResponseStatus(code = HttpStatus.NO_CONTENT)
    public void excluirPorId(@PathVariable Integer id) {
        var pessoaOptional = repository.findById(id);
        if (pessoaOptional.isEmpty()) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
        }
       repository.delete(pessoaOptional.get());
    }
	
	 @PutMapping("/{id}")
	    public Pessoa atualizarPorId(@PathVariable Integer id, @RequestBody Pessoa pessoa) {
	        var pessoaOptional = repository.findById(id);
	        if (pessoaOptional.isEmpty()) {
	            throw new ResponseStatusException(HttpStatus.NOT_FOUND);
	        }
	        pessoa.setId(id);
	        return repository.save(pessoa);
	    }

	
	
	
}
