package com.teste.crudspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
